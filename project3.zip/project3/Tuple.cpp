#include "Tuple.h"

Tuple::Tuple(/* args */){}
Tuple::~Tuple() {}

